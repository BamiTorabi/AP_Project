package process;

public enum ScoreStatus {
    PENDING, TEMPORARY, PROTESTED, ANSWERED, CONFIRMED
}
