package process;

public enum RequestStatus {
    REJECTED, PENDING, ACCEPTED;
}
